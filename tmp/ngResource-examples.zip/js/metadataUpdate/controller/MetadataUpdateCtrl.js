function MetadataUpdateCtrl($scope, $routeParams, Metadata) {

	var titleId = -1,
		revision = -1;
	
	$scope.formIsValid = {};

	$scope.showIdle = true;
	$scope.metadataUpdateConfirmation = false;
	$scope.changeSuccess = false;
	$scope.changeError = false;
	
	$scope.getMetadataUpdateJson = function(titleId, metadataFields, revision) {
		return Metadata.getMetadataUpdateJson(titleId, metadataFields, revision);
	};

	$scope.getFlatMetadata = function (metadataFields) {
		return Metadata.getFlatMetadata(metadataFields);
	}

	$scope.getMetadataAndRules = function(){
		if($routeParams.titleId != null) {
			Metadata.rules.get(function(metadataRules) {
				$scope.metadataRules = metadataRules;
				Metadata.fields.get({id: $routeParams.titleId, ts: $.now()}, function(rawMetadataFields) {
					titleId = rawMetadataFields.id;
					revision = rawMetadataFields.revision;
					$scope.metadataFields = $scope.getFlatMetadata(rawMetadataFields.fields);
					$scope.showIdle = false;
				});
			});
		}
	}

	$scope.metadataUpdateFormValidate = function(){
		var fields = $scope.formIsValid,
		    field;
		
		for(field in fields) {
			if(fields[field] == false) {
				$scope.metadataUpdateConfirmation = false;
				var input = document.querySelector("input[name='"+ field +"'].error");
				if(input){
					input.focus();
				}

				return false;
			}
		}
		
		$scope.metadataUpdateConfirmation = true;
		return true;
	};

	$scope.hasChangedField = function(){
		for (var i = 0; $scope.metadataFields && i < $scope.metadataFields.length; i++){
			if ($scope.metadataFields[i].changed) {
				return true;
			}
		}
		return false;
	};

	$scope.cancelChanges = function(){
		$scope.metadataUpdateConfirmation = false;
	};
	
	$scope.confirmChanges = function(){
		var jsonObj = $scope.getMetadataUpdateJson(titleId, $scope.metadataFields, revision);
		$scope.showIdle = true;
		$scope.metadataUpdateConfirmation = false;
		$scope.changeSuccess = false;
		$scope.changeError = false;
		Metadata.changes.save({message: JSON.stringify(jsonObj)}, function(response) {
			if(response.status != 503){
				$scope.changeSuccess = true;
			} else {
				$scope.changeError = true;
			}
			
			for (var i=0; $scope.metadataFields && i<$scope.metadataFields.length; i++){
				var field = $scope.metadataFields[i];
				if (field.changed) {
					field.changed = false;
					field.value = field.newValue;
				}
			}
			$scope.showIdle = false;
		}, function() {
			$scope.changeError = true;
			$scope.showIdle = false;
		});
	};
}