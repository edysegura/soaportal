var metadataUpdateService = angular.module('MetadataUpdateService', ['ngResource']);

metadataUpdateService.factory('Metadata', function($resource){
	return {
		fields: $resource("../titleMetadata/getMetadataFieldsFromTitle?id=:id&ts=:ts"),
		rules: $resource("../titleMetadata/getMetadataRules"),
		changes: $resource("../titleMetadata/saveMetadataFromTitle"),
    getMetadataUpdateJson : function(titleId, metadataFields, revision){
      var jsonObj = {};
      jsonObj.id = titleId;
      jsonObj.fields = [];
      for (var i = 0, len = metadataFields.length; i < len; i++){
        var field = metadataFields[i];
        if (field.changed) {
          var rootObj = metadataFields[field.rootIndex];
          if (jsonObj.fields.indexOf(rootObj) < 0) {
            jsonObj.fields.push(rootObj);
          }
        }
      }
      jsonObj.revision = revision;
      return jsonObj;
    },
    getFlatMetadata : function(metadataFields){
      var flatMetaData=[];
      for (var i=0, leng = metadataFields.length; i < leng; i++) {
        var o = metadataFields[i];
        o.cssClass = "";
        o.rootIndex = flatMetaData.length;
        o.tdColSpan = 1;
        if (o.type == "GROUP") {
          o.cssClass = "title group";
          o.tdColSpan = 3;
        }
        flatMetaData.push(o);
        if (o.name == "metadata_actors" || o.name == "metadata_directors") {
          for (var j=0; j<o.fields.length; j++) {
            for (var k=0; k<o.fields[j].length; k++) {
              var field = o.fields[j][k];
              field.cssClass = "child";
              if (k < o.fields[j].length-1) field.cssClass += " group";
              field.rootIndex = o.rootIndex;
              field.tdColSpan = 1;
              flatMetaData.push(field);
            }
            if (j < o.fields.length - 1) flatMetaData.push(o);
          }
        } else {
          for (var j=0; j<o.fields.length; j++) {
            var field = o.fields[j];
            field.cssClass = "child";
            if (k < o.fields.length-1) field.cssClass += " group";
            field.rootIndex = o.rootIndex;
            field.tdColSpan = 1;
            flatMetaData.push(field);
          }
        }
      }
      return flatMetaData;
    }
	};
});