var metadataUpdateDirective = angular.module('MetadataUpdateDirective', ['MetadataUpdateService']);

metadataUpdateDirective.directive('makeEditable', function () {
	return function (scope, element, attrs) {
		var field = scope.$eval(attrs.makeEditable);
    	
    	element.bind('focus', function () {
    		if (scope.metadataUpdateConfirmation) return;
    		//element.removeAttr('readonly');
    		element.addClass('edit');
    	});
    	
    	element.bind('keyup', function (event) {
    		scope.$apply(field.changed = element.val() != field.value);
    		scope.closePopupEvent(event);
    		return false;
    	});
    	
    	element.bind('blur', function () {
    		//element.attr('readonly', 'readonly');
    		element.removeClass('edit');
    	});
    }
});

metadataUpdateDirective.directive('charCount', function() {
	return function(scope, element, attrs){
		var field = scope.$eval(attrs.charCount);

		if(field.name && scope.metadataRules.rules[field.name]) {
			var rules = scope.metadataRules.rules[field.name];

			element.attr('maxlength', rules.maxLength);

			element.bind('focus', function () {
				element.parent().find('span').removeClass('hide');
				var length = rules.maxLength - element.val().length;
				element.parent().find('span').html(length+' left');
			});

			element.bind('keyup keydown', function(){
				var length = rules.maxLength - element.val().length;
				element.parent().find('span').html(length+' left');
			});

			element.bind('blur', function () {
				element.parent().find('span').addClass('hide');
			});

			if(field.value && field.value.length > rules.maxLength){
				field.value = field.value.substring(0, rules.maxLength);
			}
		}
	}
});

metadataUpdateDirective.directive('isRequired', function() {
	return function(scope, element, attrs) {
		var field = scope.$eval(attrs.isRequired);
		
		if(field.name && scope.metadataRules.rules[field.name]){
    		var rules = scope.metadataRules.rules[field.name];
    		
    		element.bind('blur keyup', function () {
    			if(rules.required && (/^\s+$/.test(element.val()) || element.val() == "")) {
    				element.addClass('error');
    				element.parent().find('label').removeClass('hide');
    				scope.formIsValid[field.name] = false;
    			}
    			else {
    				element.removeClass('error');
    				element.parent().find('label').addClass('hide');
    				scope.formIsValid[field.name] = true;
    			}

    		});
    	}
		
	}
});

metadataUpdateDirective.directive('undoFieldChanges', function () {
	return function (scope, element, attrs) {
		var field = scope.$eval(attrs.undoFieldChanges);
		
		element.bind('click', function () {
			field.changed = false;
			if (field.newValue == field.value) {
				//We need this to revert changes not caught by angularJS because of its input field trimming.
				//TODO: Turn of input trimming and remove this if we update angular to version 1.1.1 or newer
				field.newValue = null;
				scope.$apply(); 
			}
			field.newValue = field.value;
			
			var currentField = element.parent().parent().parent();
			currentField.find('input').removeClass('error');
			currentField.find('label').addClass('hide');
			
			scope.formIsValid[field.name] = true;
			
			if (!scope.hasChangedField() && scope.metadataUpdateConfirmation) {
				scope.cancelChanges();
			}
			
			scope.$apply();
		});
	}
});

metadataUpdateDirective.directive('buildMask', function($filter) {
	return {
		require: 'ngModel',
		link: function ($scope, element, attrs, controller) {

			var field = $scope.$eval(attrs.buildMask);

			if(field.name && $scope.metadataRules.rules[field.name]) {

				var rules = $scope.metadataRules.rules[field.name];
				if(rules.date && rules.pattern) {
					element.mask(rules.pattern);
			    	element.removeAttr('readonly');
					/* We override the render method to run the jQuery mask plugin */
					controller.$render = function () {
						var value = controller.$viewValue || '';
						element.val(value);
						element.mask(rules.pattern);
						//console.log("tamo ai");
					};

				     /* Add a parser that extracts the masked value into the model but only if the mask is valid */
				     controller.$parsers.push(function (value) {
					     //the second check (or) is only needed due to the fact that element.isMaskValid() will keep returning undefined
					     //until there was at least one key event
					     var isValid = element.isMaskValid() || angular.isUndefined(element.isMaskValid()) && element.val().length>0;
					     controller.$setValidity('mask', isValid);
					     return isValid ? value : undefined;
				     });

				     /* When keyup, update the view value
				     */
					element.bind('keyup', function() {
						$scope.$apply(function() {
							controller.$setViewValue(element.val());
						});
					});
				}
	    
				if(rules.price && rules.centsSeparator && rules.thousandsSeparator){
					NumberFormat.setNumberFormat(element[0], {
						field : field,
						maskOptions: {
							FRACTION_SEPARATOR : rules.centsSeparator,
							FRACTION_NUMBER    : 2,
							THOUSAND_SEPARATOR : rules.thousandsSeparator
						}
					});
				}
			}
		}
	}
});