function DashboardCtrl($scope, $http, Dashboard) {

	Dashboard.titleSeries.get(function(series) {
		$scope.chartData = series;
		//console.log(series);
		var dates = series.dates,
		    strDate = "",
		    objDate = null;

		for(var i=0; i<dates.length; i++) {
			strDate = dates[i];
			objDate = Date.parseExact(strDate, "dd/MM/yyyy");
			dates[i] = objDate.toString("yyyy-MM-dd");
		}

		DistributionChart.resetYAxisMaxValue();
		(new DistributionChartPaginator(series)).init();
	});

	Dashboard.monthlyWork.get(function(data) {
		//console.log(data);
		$scope.monthlyWorkData = data;
	});

}