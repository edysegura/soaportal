var dashboardApp = angular.module('DashboardApp', ['DashboardServices']);

dashboardApp.config(ajaxInterceptor);