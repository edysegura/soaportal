var dashboardServices = angular.module('DashboardServices', ['ngResource']);

dashboardServices.factory('Dashboard', function($resource){
	return {
		titleSeries: $resource("getTitleSeries"),
		monthlyWork: $resource("getMonthlyWork")
	}
});