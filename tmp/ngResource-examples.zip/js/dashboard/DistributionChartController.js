
DistributionChartController = (function() {

	var 
	_DAILY = 'daily', 
	_MONTHLY = 'monthly',
	_lastUnitSelected = 'daily',
	_startDate = null, 
	_endDate = null,

	_showMonthlyWorkStatusData = function(start, end, unit) {
		_startDate = start;
		_endDate = end;
		_lastUnitSelected = (unit) ? unit : _lastUnitSelected;
		
		$.ajax({
			//url : "../static/js/json/chart-json.js",
			dataType : 'json',
			data : {
				startDate : start,
				endDate : end,
				unit : _lastUnitSelected
			},
			success : function(series) {
				DistributionChart.resetYAxisMaxValue();
				(new DistributionChartPaginator(series)).init();
			},
			error: function(jqXHR, textStatus, errorThrown){
				_onError(jqXHR, textStatus, errorThrown);
			}
		});
	},
	
	_onError = function(jqXHR, textStatus, errorThrown){
		if(jqXHR.status = 200 && ( (/class="login"/).test(jqXHR.responseText) )){
			CMSaaSJS.hideMessageError();
	
			var msgError = document.getElementById("errorSessionHasExpired").value;
			
			$.blockUI({
				message: msgError,
				css: { 
	                width: '344px',
	                height: '60px',
	                border: 'none', 
	                backgroundColor: 'transparent',
	                cursor : 'default'
	            },
				baseZ: 1001,
				overlayCSS: {
					opacity: .3,
					cursor : 'default'
				},
				
			    onBlock: function(){
			    	document.activeElement.blur();
			    }
			});
			
		}
	},
	
	_showCurrentMonth = function() {
		var d = new Date(),
			month = parseInt(d.getMonth()),
			year = parseInt(d.getFullYear()), 
			start = DateUtil.getFirstDate(month, year),  
			end = DateUtil.getLastDate(month, year);
		 
		_showMonthlyWorkStatusData(start, end, _lastUnitSelected);
		
	},

	_showDaily = function() {
		_showMonthlyWorkStatusData(_startDate, _endDate, _DAILY);
	},

	_showMonthly = function() {
		_showMonthlyWorkStatusData(_startDate, _endDate, _MONTHLY);
	};

	return {
		showMonthlyWorkStatusData : _showMonthlyWorkStatusData,
		showDaily: _showDaily,
		showMonthly: _showMonthly,
		showCurrentMonth: _showCurrentMonth
	};

})();
