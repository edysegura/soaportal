DistributionChartPaginatorFacade = (function(){
	var _init = function(series) {
		(new DistributionChartPaginator(series)).init();
	};

	return {
		init: _init
	};
})();