/**
 * Monthly Status Chart
 */
DistributionChart = (function(){

	var 
		_chartId = 'distributionChart',
		_tooltipId = '#chartTooltip',
		_plot = null,
		_yaxisDefaultMaxValue = 10,
		_yaxisMaxValue = _yaxisDefaultMaxValue,
		_cssClassTooltipFailed = 'tooltip-failed';
	
	var _showChart = function(series) {
		var 
			seriesCompleted = series.completed,
			seriesFailed = series.failed,
			dates = series.dates,
			unit = series.unit;

		if(!seriesCompleted){
			throw new Error("Series completed is missing");
		}

		if(!seriesFailed){
			throw new Error("Series failed is missing");
		}
		
		if(!dates){
			throw new Error("Series dates is missing");
		}

		if(unit != 'monthly' && unit != 'daily' ) {
			throw new Error("Series unit is missing or not is monthly or daily");
		}
		
		if(seriesCompleted.length != dates.length || seriesFailed.length != dates.length || seriesCompleted.length != seriesFailed.length) {
			throw new Error("Completed, failed and date series should have the same size");
		}

		_setChartDescription(series);	
		_plot = $.jqplot(_chartId, [seriesCompleted,seriesFailed], _getChartOptions(series));
		_setTooltip(series);
		
		if(unit != 'monthly') {
			_setAxisTooltip();
		}
		
	};
	
	var _setChartDescription = function(series) {
		var 
			dates = series.dates,
			unit = series.unit,
			firstDate = dates[0],
			lastDate = dates[dates.length - 1],
			chartContainer = document.getElementById('chartContainer'),
			dateDescription = null,
			view = (unit == 'daily') ? "day" : 'month';
		
		if(unit == 'monthly') {
			
			var d = null,
				month = null,
				year = null;
			
			
			if($("#currentMonth").is(":checked"))
			{
				d = new Date();
				month = parseInt(d.getMonth());
				year = parseInt(d.getFullYear());
					
				firstDate = DateUtil.getFirstDate(month, year);
				lastDate = DateUtil.getLastDate(month, year);
			}
			else
			{
				var startInput = $("#_dist_from_id").val(),
					endInput = $("#_dist_to_id").val(),
					startDate = startInput.substring(3),
					endDate = endInput.substring(3);
								
				if(firstDate == startDate)	{
					firstDate = startInput;
				}
				else {
					d = firstDate.split('/');
					month = parseInt(d[0]) - 1;
					year = parseInt(d[1]);
					
					firstDate = DateUtil.getFirstDate(month, year);
				}
					
				if(lastDate == endDate)	{
					lastDate = endInput;
				}
				else {
					d = lastDate.split('/');
					month = parseInt(d[0]) - 1;
					year = parseInt(d[1]);
					
					lastDate = DateUtil.getLastDate(month, year);
				}
			}
		}
		
		firstDate = new Date(firstDate).toString(series.dateFormat);
		lastDate  = new Date(lastDate).toString(series.dateFormat);

		if(firstDate != lastDate) {
			dateDescription = firstDate + " - " + lastDate;
		}
		else {
			dateDescription = firstDate;
		}
			
		$(".chart h3", chartContainer).text("Distribution status per " + view );
		
		$(".chart h4", chartContainer).text("Showing " + dateDescription );
	};
	
	var _setTooltip = function(series) {
		$('#' + _chartId).bind('jqplotDataHighlight', 
			function (ev, seriesIndex, pointIndex, data) {
				var 
					mouseX = ev.pageX, //these are going to be how jquery knows where to put the div that will be our tooltip
					mouseY = ev.pageY,
					xOffset = 20,
					failedIndex = 1;
					
				var cssObj = {
					'position' : 'absolute',
					'font-weight' : 'bold',
					'left' : (mouseX + xOffset) + 'px', //usually needs more offset here
					'top' : mouseY + 'px'
				};
				
				if(seriesIndex == failedIndex) {
					$(_tooltipId).addClass(_cssClassTooltipFailed);
				}
				else {
					$(_tooltipId).removeClass(_cssClassTooltipFailed);
				}
				
				$(_tooltipId)
					.css(cssObj)
					.html('<p>Titles ' + _plot.series[seriesIndex].label + ': ' + data[1] + '</p>')
					.append('<p>' + series.dates[pointIndex] + '</p>')
					.show();
			}
		);
	 
		$('#' + _chartId).bind('jqplotDataUnhighlight', 
			function (ev) {
				$(_tooltipId)
					.hide()
					.removeClass(_cssClassTooltipFailed)
					.html('');
			}
		);
	};
	
	var _setAxisTooltip = function() {
		
		$(".jqplot-xaxis-tick")
		.css({
			cursor: "arrow",
			zIndex: "1"
		})
		.mouseover(function(e){ 
			var 
				mouseX = e.pageX,
				mouseY = e.pageY,
				xOffset = 20;
				yOffset = 5;
					
			var cssObj = {
				'position' : 'absolute',
				'font-weight' : 'bold',
				'zIndex' : '3',
				'left' : (mouseX + xOffset) + 'px',
				'top' : (mouseY + yOffset) + 'px'
			};
			
			$(_tooltipId).addClass('tooltip-xaxis');
			
			$(_tooltipId)
				.css(cssObj)
				.html('<p>' + $(this).children('span').attr('data-tooltipDate') + '</p>')
				.show();
		}).mouseout(function(){
			$(_tooltipId)
				.hide()
				.removeClass('tooltip-xaxis')
				.html('');
		});	
	};
	
	var _formartTicks = function(series) {
		var 
			newTicks = [],
			ticks = series.dates,
			strDate = "", 
			formattedDate = "";
		
		for(var i=0, leng = ticks.length; i<leng; i++) {
			strDate = ticks[i];
			if(series.unit == 'daily') {
				formattedDate = new Date(strDate).toString('dd');
				newTicks.push('<span data-tooltipDate="' + (new Date(strDate).toString(series.dateFormat)) + '">' + formattedDate + '</span>');
			}
			else {
				formattedDate = new Date(strDate).toString('MMM<br />yyyy');
				newTicks.push(formattedDate);
			}
		}

		return newTicks;
	};
		
	var _getChartOptions = function(series){
		
		var total = 0,
			factor = 10;
		
		for(var i = 0, leng = series.completed.length; i < leng; i++)
		{
			total = series.completed[i] + series.failed[i];
			
		    if(total > _yaxisMaxValue)
		    {
		    	_yaxisMaxValue = total + factor;
		    }		    
		}
		
		var chartOptions = {
			stackSeries: true,
			animate: true,
			animateReplot: true,
			seriesDefaults: {
				renderer:$.jqplot.BarRenderer,
				pointLabels: { show: false },
				shadow: false,
				rendererOptions: {
					barWidth: 10
				}
			},
			series: [
				{label: 'Completed', color: '#c6ecbe'},
				{label: 'Failed', color: '#f2b9b9'}
			],
			axes: {
				xaxis: {
					renderer: $.jqplot.CategoryAxisRenderer,
					drawMajorGridlines: false,
					ticks: (function(){ return _formartTicks(series); })(),
					tickRenderer: $.jqplot.AxisTickRenderer
				},
				yaxis: {
					padMin: 0,
					min: 0,
					max: _yaxisMaxValue,
					numberTicks: 6,
					rendererOptions: {
						forceTickAt0: true,
						drawBaseline: false
					},
					tickOptions: { 
			            formatString: '%d' 
			        } 
				}
			},
			legend: {
				show: true,
				location: 's',
				placement: 'outsideGrid',
				renderer: $.jqplot.EnhancedLegendRenderer,
				rendererOptions: {
					numberRows: 1
				}
			},
			grid: {
				background: '#ffffff',
				shadow: false,
				drawBorder: false
			}
		};
		
		if(series.withoutAnimateReplot) {
			chartOptions.animateReplot = false;
		}
		
		return chartOptions;
	};
	
	var _resetYAxisMaxValue = function()
	{
		_yaxisMaxValue = _yaxisDefaultMaxValue;
	};
	
	var _replot = function(series) {
		if(_plot) {
			_showChart(series);
			_plot.replot();
			
			if(series.unit != 'monthly') {
				_setAxisTooltip();
			}			
		}
		else {
			_showChart(series);
		}
	};
	
	//public things
	return {
		plot: _replot,
		formartTicks: _formartTicks,
		resetYAxisMaxValue: _resetYAxisMaxValue
	};
	
})();