/*
 * This module is responsable to paginate a chart series
 */
DistributionChartPaginator = (function(series) {
	
	var 
	_index = 0,
	_maxItens = 31,
	_series = series,
	_leftItens = null,
	_newSeries = series,
	_navCSSClass = '.navChartIcon',
	_navCSSLeftClass = '.prev',
	_navCSSRightClass = '.next',
	_removeChartAnimation = true,

	_init = function() {
		$(_navCSSClass).hide();
		
		if(_series.unit == 'monthly')
		{
			_maxItens = 12;
		}
		
		if(_series.dates.length > _maxItens) {
			_setup();
			_plot();
			$(_navCSSRightClass).show();
		}
		else {
			DistributionChart.plot(_series);
		}
	},
	
	_setup = function() {
		var 
			timerId = null,
			secondsToHold = 200,
			areaPrevClass = '.areaprev',
			areaNextClass = '.areanext',
			chartContainer = document.getElementById('chartContainer');
		
		$(areaPrevClass, chartContainer).unbind();
		$(areaNextClass, chartContainer).unbind();
		
		$(areaPrevClass, chartContainer).click(function(){
			_shiftLeft();
		})
		.mouseover(function() {
			timerId = window.setInterval(function(){
				_shiftLeft();
			}, secondsToHold);
		})
		.mouseout(function(){
			window.clearInterval(timerId);
		});
		
		$(areaNextClass, chartContainer).click(function(){
			_shiftRight();
		})
		.mouseover(function(){
			timerId = window.setInterval(function(){
				_shiftRight();
			}, secondsToHold);
		})
		.mouseout(function(){
			window.clearInterval(timerId);
		});
	},

	_shiftLeft = function(index) {
		if (_index > 0) {
			_index--;
			_plot(_removeChartAnimation);
			$(_navCSSRightClass).show();
		}
		else {
			$(_navCSSLeftClass).hide();
		}
		return false;
	},

	_shiftRight = function(index) {
		if (_leftItens > _maxItens) {
			_index++;
			_plot(_removeChartAnimation);
			$(_navCSSLeftClass).show();
		}
		else {
			$(_navCSSRightClass).hide();
		}
		return false;
	},
	
	_generateSeries = function(withoutAnimation) {
		var newSeries = {};
		newSeries.unit = _series.unit;
		newSeries.dates = _slice(_series.dates);
		newSeries.completed = _slice(_series.completed);
		newSeries.failed = _slice(_series.failed);
		
		if(withoutAnimation) {
			newSeries.withoutAnimateReplot = true;
		}
		else {
			newSeries.withoutAnimateReplot = false;
		}
		_newSeries = newSeries;
		return _newSeries;
	},
	
	_slice = function(serie){
		_leftItens = (_series.dates.slice(_index)).length;
		return serie.slice(_index, _index + _maxItens);
	},
	
	_plot = function(withoutAnimation) {
		var series = _generateSeries(withoutAnimation);
		if(withoutAnimation) {
			series.withoutAnimation = true;
		}
		DistributionChart.plot(series);
	};
	
	return {
		init: _init
	};

});
