var systemDirectives = angular.module('SystemDirectives', []);

systemDirectives.directive('toggleBoxes', function() {
	return function(scope, element, attrs) {
		element.bind('click', function() {
			var boxDiv = this.parentNode.getElementsByTagName('div')[0];

			$('.box').hide();

			$(boxDiv).css({
				display: function(index, value) {
					return (value === 'none') ? 'block' : 'none';
				}
			});
			$(boxDiv).find("input[type='checkbox']").attr('checked', false);
		});
	}
});

systemDirectives.directive('closeBoxes', function() {
	return function(scope, element, attrs) {
		element.bind('click', function() {
			$('.box').hide();
		});
	}
});
