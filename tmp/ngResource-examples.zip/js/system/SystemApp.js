var systemApp = angular.module('systemApp', ['SystemDirectives', 'GeneralDirectives']);

systemApp.config(ajaxInterceptor);