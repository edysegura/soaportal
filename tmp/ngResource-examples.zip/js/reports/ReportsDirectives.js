var reportsDirectives = angular.module('ReportsDirectives', []);

reportsDirectives.directive('changeTemplate', function() {
	return function(scope, element, attrs) {

		element.bind('click', function() {
			$(this).parents('ul').find('li').removeClass('current');
			$(this).parent().addClass('current');

			var template = attrs.changeTemplate;
			switch (template) {
			case "workStatus":
				scope.$apply(function() {
					scope.templateUrl = scope.reportsTemplates[0].url
				});
				break;
			case "assetHours":
				scope.$apply(function() {
					scope.templateUrl = scope.reportsTemplates[1].url
				});
				break;
			case "transitTime":
				scope.$apply(function() {
					scope.templateUrl = scope.reportsTemplates[2].url
				});
				break;
			default:
				scope.$apply(function() {
					scope.templateUrl = scope.reportsTemplates[0].url
				});
			}
		});
	}
});

reportsDirectives.directive('plotChart', function(){
	return function(scope, element, attrs) {
		scope.$on('plotChart', function(event, isActive) {
				if(!isActive) {
					var series = {};
					
					series.dates = scope.workStatus.graph.dates;
					series.completed = scope.workStatus.graph.successes;
					series.failed = scope.workStatus.graph.failures;
					series.unit = 'daily';
					series.dateFormat = 'dd/MM/yyyy';

					DistributionChart.resetYAxisMaxValue();
					DistributionChartPaginatorFacade.init(series);
				}
		});
	}
});

reportsDirectives.directive('fixHeader', function(){
	return function(scope, element, attrs) {
		var topFixed = document.getElementById('top-fixed'),
			table    = document.getElementById('report-work-status');
		
		if(table) {
			$(window).scroll(function(){
				var toptable  = $(table).offset().top,
					topscroll = Math.max(0, toptable - $(this).scrollTop());
				
				if(topscroll === 0) {
					$(topFixed).show();
					$(topFixed).css("top",topscroll);
				}
				else {
					$(topFixed).hide();
				}
			});
		}
	}
});

reportsDirectives.directive('hasTitle', function(){
	return function(scope, element, attrs) {
		var reportDay = scope.$eval(attrs.hasTitle);
		
		if(reportDay.titles.length === 0) {
			element.addClass('uncollapse');
			$(element).find('span[class=info]').remove();
			element.find('td').append('<span class="info"><span>0</span> titles</span>');
		}
	}
});