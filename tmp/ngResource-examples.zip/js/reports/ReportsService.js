var reportsService = angular.module('ReportsService', ['ngResource']);

reportsService.factory('Reports', function ($resource) {
  return {
  	//workStatus : $resource('../js/json/workStatusReport-server.json')
  	workStatus : $resource('getWorkStatusReport')
  };
});