var reportsApp = angular.module('reportsApp', ['ReportsDirectives', 'ReportsService', 'DefaultFilters', 'GeneralDirectives', 'titlesApp']);

reportsApp.config(ajaxInterceptor);