function ReportsCtrl($scope, Reports, $location, $rootScope) {

	$scope.reportsTemplates = [ {
		name : 'workStatus',
		url : '../ng-templates/reports/workStatus.gsp'
	}, {
		name : 'assetHours',
		url : '../ng-templates/reports/assetHours.gsp'
	}, {
		name : 'transitTime',
		url : '../ng-templates/reports/transitTime.gsp'
	}];
	
	var currentTitleSearch = "",
	resetCurrentTab = function() {
		$('#listMenu').find('li').removeClass('current');
		$('#detailsTab').addClass('current');
	};
	
	/*===========================================
	Templates variables
	===========================================*/
	$scope.templates = [ {
		name : 'idle',
		url : '../ng-templates/titles/idle.gsp'
	}, {
		name : 'grid',
		url : '../ng-templates/titles/grid.gsp'
	}, {
		name : 'list',
		url : '../ng-templates/titles/list.gsp'
	}];
	$scope.template = $scope.templates[1];

	$scope.popupTemplates = [ {
		name : 'index',
		url : '../ng-templates/popup/index.gsp'
	}, {
		name : 'details',
		url : '../ng-templates/popup/details.gsp'
	}, {
		name : 'metadata',
		url : '../ng-templates/popup/metadata.gsp'
	}];

	$scope.popupTemplate = $scope.popupTemplates[1];
	
	$rootScope.modalShown = false;
	
	$scope.workStatus = {};

	$scope.templateUrl = $scope.reportsTemplates[0].url;

	$scope.getWorkStatusReport = function(){
		Reports.workStatus.get(function(response){
			$scope.workStatus = response;
		});
	};
	
	$scope.titleClick = function(title) {
		
		$scope.currentTitleId = title.id;
		
		if(!title.markedForDeletion){
			$scope.popupTemplate = $scope.popupTemplates[1];
			$location.path('/details/'+title.id);
			$rootScope.modalShown = true;
		} else {
			return;
		}
		
	};
	
	$scope.showThumbnail = function(title, thumbnailSize) {
		if(title && title.posterUrls){
				var posterUrls = title.posterUrls;

				if(posterUrls && ( posterUrls.mediumThumbnail || posterUrls.smallThumbnail )){
					if(posterUrls.smallThumbnail && thumbnailSize == 'small') {
						return posterUrls.smallThumbnail;
					} else if(posterUrls.mediumThumbnail && thumbnailSize == 'medium'){
							return posterUrls.mediumThumbnail;
					}
				}
			}
			return "../images/_popup-thumb.jpg";
	};
	
	/*===========================================
	Popup
	===========================================*/
	$scope.hasChangedField = function(){
		if($('.statusUndo').is(":visible") === true) {
			return true;
		}
		return false;
	};
	
	$scope.closePopup = function() {
		if($scope.metadataTab === true && $scope.hasChangedField()) {
			if($window.confirm('Are you sure you want to close the screen?')) {
				$rootScope.closeAndResetPopup();
			}
		}
		else {
			$rootScope.closeAndResetPopup();
		}
	};
	
	$rootScope.closeAndResetPopup = function() {
		resetCurrentTab();
		$rootScope.modalShown = false;
		$location.path('/');
	};
	
	$scope.closePopupEvent = function(event) {
		if(event.which == 27 && $rootScope.modalShown === true) {
			$scope.closePopup();
			$scope.$digest();			
		}
		else {
			event.preventDefault();
			event.stopPropagation();
		}
	};

}