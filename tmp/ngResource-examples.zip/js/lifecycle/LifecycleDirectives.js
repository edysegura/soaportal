var lifecycleDirectives = angular.module('LifecycleDirectives', []);

lifecycleDirectives.directive('toggleBoxes', function() {
	return function(scope, element, attrs) {
		element.bind('click', function() {
			var linkOffset = $(this).offset(),
			boxDiv = this.parentNode.getElementsByTagName('div')[0];

			$('.box').hide();

			$(boxDiv).css({
				display: function(index, value) {
					return (value === 'none') ? 'block' : 'none';
				}
			});
			$(boxDiv).offset({top:linkOffset.top + this.offsetHeight, left:linkOffset.left});
		});
	}
});

lifecycleDirectives.directive('closeBoxes', function() {
	return function(scope, element, attrs) {
		element.bind('click', function() {
			$('.box').hide();
		});
	}
});