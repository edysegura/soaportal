var titlesDirectives = angular.module('titlesDirectives', []);

titlesDirectives.directive('globalEvents', function($document) {
	return function(scope, element, attrs) {
		// Put your events here
		$document.on("keyup", (function(event) {
			var listeners = scope.keyupListeners,
				listener = null;
			
			for(var i=0; i<listeners.length; i++) {
				listener = listeners[i];
				if(typeof listener == 'function') {
					listener(event);
				}
			}
		}));
	};
});

titlesDirectives.directive('onKeyupFn', function() {
	return function(scope, element, attrs) {
		// Evaluate the variable that was passed
		// In this case we're just passing a variable that points
		// to a function we'll call each keyup
		var keyupFn = scope.$eval(attrs.onKeyupFn);
		element.bind('keyup', function(evt) {
			// $apply makes sure that angular knows
			// we're changing something
			scope.$apply(function() {
				keyupFn.call(scope, evt.which);
			});
		});
	};
});

titlesDirectives.directive('onKeyup', function() {
	return function(scope, element, attrs) {
		function applyKeyup() {
			scope.$apply(attrs.onKeyup);
		}

		var allowedKeys = scope.$eval(attrs.keys);
		element.bind('keyup', function(evt) {
			// if no key restriction specified, always fire
			if (!allowedKeys || allowedKeys.length === 0) {
				applyKeyup();
			} else {
				angular.forEach(allowedKeys, function(key) {
					if (key == evt.which) {
						applyKeyup();
					}
				});
			}
		});
	};
});

titlesDirectives.directive('btnViewChange', function(){
	return function(scope, element, attrs){
		element.bind('click', function(){
			if(this.id === 'btn-gridView'){
				scope.$apply(scope.template = scope.templates[1]);
				$(this).addClass('selected');
				$(this).parent().find('#btn-listView').removeClass('selected');
			} else{
				scope.$apply(scope.template = scope.templates[2]);
				$(this).addClass('selected');
				$(this).parent().find('#btn-gridView').removeClass('selected');
			}
		});
	};
});

titlesDirectives.directive('markForDeletion', function(){
	return function(scope, element, attrs){
		var title = scope.$eval(attrs.markForDeletion);
		
		if(title.markedForDeletion){
			element.addClass('deleted');
		}
	};
});

titlesDirectives.directive('isValidPageNumber', function(){
	return function(scope, element, attrs){
		element.bind('keyup keydown', function(){
			var page = element.val();
			if((page > 0 && page <= scope.$parent.titleSearchResult.numPages && !isNaN(page)) || scope.$parent.showIdle){
				element.removeClass('invalid');
			} else {
				element.addClass('invalid');
			}
		});
	};
});

titlesDirectives.directive('toggleReports', function(){
	return function(scope, element, attrs){
		element.bind('click', function(){
			div = $(this).parent().find('div');
			$('.qc-box').hide();
			$(div).css({
				display: function(index, value) {
					return (value === 'none') ? 'block' : 'none';
				}
			});
		});
	};
});

titlesDirectives.directive('closeReports', function(){
	return function(scope, element, attrs){
		element.bind('click', function() {
			$('.qc-box').hide();
		});
	};
});

titlesDirectives.directive('verifyCurrentTab', function() {
	return function(scope, element, attrs) {

		element.bind('click', function () {
		  var tabName = this.getAttribute('data-tab');
		  switch (tabName) {
				case 'details':
					$('#listMenu').find('li').removeClass('current');
					$('#detailsTab').addClass('current');
					scope.metadataTab = false;
					break;

				case 'metadata':
					$('#listMenu').find('li').removeClass('current');
					$('#metadataTab').addClass('current');
					scope.metadataTab = true;
					break;

				case 'preview':
					$('#listMenu').find('li').removeClass('current');
					$('#previewTab').addClass('current');
					scope.metadataTab = false;
					break;

				case 'lifecycle':
					$('#listMenu').find('li').removeClass('current');
					$('#lifecycleTab').addClass('current');
					scope.metadataTab = false;
					break;
		  };
		});
	};
});