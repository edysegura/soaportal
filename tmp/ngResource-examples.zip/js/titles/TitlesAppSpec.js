'use strict';

xdescribe('TitleApp', function() {
  //TODO: Make a new tests here to ensue if TItles Controller is working correctly

  describe('Titles listing factors', function() {
    //TODO: Make a new tests here to ensure if Title Listing is working correctly 
    describe('the poster should be displayed on grid view', function() {
      
      beforeEach(module('titlesApp', ['ui']));
      //beforeEach(module('titlesApp'));

      it('when title have a link to image of poster then a poster link should be displayed', inject(function(showThumbnail) {
        var title = {
          "posterUrl" : {
            "mediumThumbnailUrl": "http://somedomain.com/someFolder/someMediumFile.jpg",
            "smallThumbnailUrl": "http://somedomain.com/someFolder/someSmallFile.jpg"
          }
        };

        expect(showThumbnail(title, "small")).toEqual("http://somedomain.com/someFolder/someSmallFile.jpg");
      }))
    });
  });
});