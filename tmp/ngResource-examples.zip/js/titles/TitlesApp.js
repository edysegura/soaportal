var titlesApp = angular.module('titlesApp', [ 'ui', 'titlesService',
		'titlesDirectives', 'LifecycleDirectives', 'PreviewDirectives',
		'MetadataUpdateApp', 'GeneralDirectives' ]);

titlesApp.config([
	'$routeProvider', '$provide', '$httpProvider',
	function($routeProvider, $provide, $httpProvider, $window) {
		$routeProvider.when('/details/:titleId', {
			templateUrl : '../ng-templates/popup/details.gsp',
			controller : TitleDetailsCtrl
		}).when('/metadata/:titleId', {
			templateUrl : '../ng-templates/popup/metadata.gsp',
			controller : MetadataUpdateCtrl
		}).when('/preview/:titleId', {
			templateUrl : '../ng-templates/popup/preview.gsp',
			controller : PreviewCtrl
		}).when('/lifecycle/:titleId', {
			templateUrl : '../ng-templates/popup/lifecycle.gsp',
			controller : LifecycleCtrl
		}).otherwise({
			redirectTo : '/'
		});
	}
]);

titlesApp.config(ajaxInterceptor);