function TitleDetailsCtrl($rootScope, $scope, $window, $location, $routeParams, Title) {
	$scope.showIdle = true;
	$scope.titleDetails = {};

	$scope.getTitleDetails = function(){
		Title.details.get({id: $routeParams.titleId, ts: $.now()}, function(titleDetails){
			$scope.titleDetails = titleDetails;
			$scope.showIdle = false;
		});
	};

	$scope.deleteTitle = function(titleId){
		if($window.confirm('Are you sure you want delete this title?')) {
			$scope.showIdle = true;
			Title.deleteTitle.save({message: JSON.stringify({id:titleId})}, function(response) {
				if(response.status != 503){
					$scope.showIdle = false;
					$window.alert("This Title has been deleted.");
					$rootScope.closeAndResetPopup();
					$window.location.reload();
				} else {
					$scope.showError = true;
					$scope.showIdle = false;
				}
			}, function() {
				$scope.showError = true;
				$scope.showIdle = false;
			});
		} else {
			return;
		}
	};
}