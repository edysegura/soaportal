function TitlesCtrl($window, $rootScope, $scope, $routeParams, $location, $http, $filter, Title) {

	/*===========================================
	Commons variables
	===========================================*/	
	var currentTitleSearch = "",
		resetCurrentTab = function() {
			$('#listMenu').find('li').removeClass('current');
			$('#detailsTab').addClass('current');
		};

	$rootScope.modalShown = false;

	$scope.page = 1;
	$scope.pageSize = 8;

	$scope.titleSearch;
	$scope.titleSearchResult = [];
	$scope.titleId;

	$scope.showIdle = false;

	$scope.metadataTab = false;
	
	$scope.keyupListeners = [];

	$scope.addKeyupListener = function(listener) {
		$scope.keyupListeners.push(listener);
	};
	
	/*===========================================
	Templates variables
	===========================================*/
	$scope.templates = [ {
		name : 'idle',
		url : '../ng-templates/titles/idle.gsp'
	}, {
		name : 'grid',
		url : '../ng-templates/titles/grid.gsp'
	}, {
		name : 'list',
		url : '../ng-templates/titles/list.gsp'
	}];
	$scope.template = $scope.templates[1];

	$scope.popupTemplates = [ {
		name : 'index',
		url : '../ng-templates/popup/index.gsp'
	}, {
		name : 'details',
		url : '../ng-templates/popup/details.gsp'
	}, {
		name : 'metadata',
		url : '../ng-templates/popup/metadata.gsp'
	}];

	$scope.popupTemplate = $scope.popupTemplates[1];
	
	/*===========================================
	Title listing and Title details
	===========================================*/
	$scope.getTitleList = function(){
		if(currentTitleSearch === ''){
			$scope.searchTitles(currentTitleSearch, $scope.page, $scope.pageSize);
		}
	};

	$scope.searchTitles = function(titleSearch, page, pageSize) {
		if (!titleSearch) {
			titleSearch = "";
		}

		$scope.showIdle = true;
		$scope.titleSearchResult = Title.list.get({displayTitle : titleSearch, page : page, pageSize : pageSize, ts : $.now()}, function() {
			$scope.page = $scope.titleSearchResult.page;
			currentTitleSearch = titleSearch;
			$scope.showIdle = false;
		});
	};

	$scope.showThumbnail = function(title, thumbnailSize) {
		if(title && title.posterUrls){
				var posterUrls = title.posterUrls;

				if(posterUrls && ( posterUrls.mediumThumbnail || posterUrls.smallThumbnail )){
					if(posterUrls.smallThumbnail && thumbnailSize == 'small') {
						return posterUrls.smallThumbnail;
					} else if(posterUrls.mediumThumbnail && thumbnailSize == 'medium'){
							return posterUrls.mediumThumbnail;
					}
				}
			}
			return "../images/_popup-thumb.jpg";
	};

	$scope.showPagination = function() {
		if($scope.titleSearchResult.numPages > 0) {
			return true;
		} else {
			return false;
		}
	};

	$scope.goToPage = function(page) {
		var numPages = $scope.titleSearchResult.numPages, pageSize = $scope.pageSize;

		switch(page) {
			case "first":
				if(numPages > 0 && $scope.page != 1) {
					$scope.searchTitles(currentTitleSearch, 1, pageSize);
				}
				break;
			case "prev":
				if(numPages > 0 && $scope.page > 1) {
					$scope.searchTitles(currentTitleSearch, $scope.page-1, pageSize);
				}
				break;
			case "next":
				if(numPages > 0 && $scope.page < numPages) {
					$scope.searchTitles(currentTitleSearch, $scope.page+1, pageSize);
				}
				break;
			case "last":
				if(numPages > 0 && $scope.page <= numPages) {
					$scope.searchTitles(currentTitleSearch, numPages, pageSize);
				}
				break;
			default:
				if(page > 0 && page <= numPages && !isNaN(page)) {
					$scope.searchTitles(currentTitleSearch, page, pageSize);
				}
		}
	};
	
	$scope.titleClick = function(title) {
		
		$scope.currentTitleId = title.id;
		
		if(!title.markedForDeletion){
			$scope.popupTemplate = $scope.popupTemplates[1];
			$location.path('/details/'+title.id);
			$rootScope.modalShown = true;
		} else {
			return;
		}
		
	};

	$scope.titleDisplayTooltip = function(titleDisplay) {
		if(titleDisplay.length > 40) {
			return titleDisplay;
		} else {
			return '';
		}
	};

	$scope.actualTitleDisplay = function(titleDisplay) {
		if(titleDisplay.length > 40) {
			return titleDisplay.substring(0, 40).concat('...');
		} else {
			return titleDisplay;
		}
	};

	$scope.addHideClass = function(paginationButton) {
		switch(paginationButton) {
		case "first":
		case "prev":
				if($scope.page === 1) {
					return "hide";
				} else {
					return "";
				}
		break;
		
		case "next":
		case "last":
				if($scope.page === $scope.titleSearchResult.numPages) {
					return "hide";
				} else {
					return "";
				}
		break;
		default:
				return "";
		}
	};

	$scope.formatDateString = function(dateString) {
		var newdateString = "";
		if (dateString){
			var date = new Date(dateString);
			newdateString = $filter('date')(date, 'dd/MM/yyyy HH:mm:ss');
		}
		return newdateString;
	};
	
	$scope.stopPropagation = function(event) {
		event.stopPropagation();
		return false;
	};

	/*===========================================
	Popup
	===========================================*/
	$scope.hasChangedField = function(){
		if($('.statusUndo').is(":visible") === true) {
			return true;
		}
		return false;
	};
	
	$scope.closePopup = function() {
		if($scope.metadataTab === true && $scope.hasChangedField()) {
			if($window.confirm('Are you sure you want to close the screen?')) {
				$rootScope.closeAndResetPopup();
			}
		}
		else {
			$rootScope.closeAndResetPopup();
		}
	};
	
	$rootScope.closeAndResetPopup = function() {
		resetCurrentTab();
		$rootScope.modalShown = false;
		$location.path('/');
	};
	
	$scope.closePopupEvent = function(event) {
		if(event.which == 27 && $rootScope.modalShown === true) {
			$scope.closePopup();
			$scope.$digest();			
		}
		else {
			event.preventDefault();
			event.stopPropagation();
		}
	};

	$scope.addKeyupListener($scope.closePopupEvent);
}