var titlesService = angular.module('titlesService', ['ngResource']);

titlesService.factory('Title', function($resource) {
	return {
		list: $resource("../titles/getTitles?displayTitle=:displayTitle&page=:page&pageSize=:pageSize&ts=:ts"),
		details: $resource("../titles/getTitleDetails?titleId=:id&ts=:ts"),
		deleteTitle: $resource("../titleMetadata/deleteTitle")
	};
});