var previewDirectives = angular.module('PreviewDirectives', []);

previewDirectives.directive('changeVideo', function() {
	return function(scope, element, attrs) {
		element.bind('click', function() {
			var li = $(this),
				videoId = ((li.find('img').attr('src')).split("/"))[4];

			scope.$apply(function() {
				scope.nowPlaying.name = li.find('span').attr('title');
				scope.nowPlaying.url = "http://www.youtube.com/embed/" + videoId
			});

			var firstLi = li.parent().find('li').first(),
				firstLiPrevContent = firstLi.html(); 
			firstLi.html(li.html());
			li.html(firstLiPrevContent);
		});
	}
});