function PreviewCtrl($scope) {

	$scope.nowPlaying = {
		name : 'Time to Play',
		url : 'http://www.youtube.com/embed/zh2d9cRMMK4'
	};

}