var generalDirectives = angular.module('GeneralDirectives', []);

generalDirectives.directive('toggleElement', function(){
	return function(scope, element, attrs) {
		element.bind('click', function() {
			if($(this).parent().hasClass('day-info')) {
				$(this).parents('tbody').find('.toggle').toggle();
			}
			else {
				$(this).next().slideToggle("slow");
				if($(this).hasClass('contentGraph')) {
					scope.$emit('plotChart', $(this).hasClass('active'));
				}
			}
	
			$(this).toggleClass('active');
		});
	}
});

generalDirectives.directive('truncate', function(){
	return function(scope, element, attrs) {
		var args = attrs.truncate.split(" "),
		 	text   = scope.$eval(args[0]),
			length = args[1];
		
		if(text && length) {
			if(text.length > length && !isNaN(length)) {
				element.text(text.substring(0, length).concat('...'));
				element.attr('title', text);
			}
		}
	}
});