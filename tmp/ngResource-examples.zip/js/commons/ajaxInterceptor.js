var ajaxInterceptor = [
	'$provide', '$httpProvider',
	function($provide, $httpProvider, $window) {
		$httpProvider.responseInterceptors.push(function($timeout, $q, $window) {
			return function(promise) {
				return promise.then(
					function(successResponse) {
						return successResponse;
					},
					function(errorResponse) {
						switch (errorResponse.status) {
							case 401 || 403 :
								alert('Your session has expired please do login again.');
								$window.location.reload();
								return $q.reject(errorResponse);
							break;
							case 500 :
								alert('We are facing some issues right now, please try again later.');
								return $q.reject(errorResponse);
							break;
							default :
								console.log('An error has occured on server.');
								return $q.reject(errorResponse);
							break;
						}
					}
				)
			}
		});
	}
];