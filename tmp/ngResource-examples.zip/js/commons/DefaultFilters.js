var defaultFilters = angular.module('DefaultFilters', []);

defaultFilters.filter('dateFormat', function() {
	return function(date, pattern) {
		if(date) {
			if(pattern === undefined || pattern === ""){
				pattern = "dd/MM/yyyy HH:mm:ss";
			}
			return new Date(date).toString(pattern);
		}
		return "";
	}
});